Climate-Tray 
============

Version: 1.2.0
Build timestamp: 2018-10-22 17:39

Climate-Tray is an application to control Mitsubishi Cooling & Heating units.
It is designed to run as tray-icon showing the current state of a device
and manipulating the state of one or more units by configurable presets.

Currently only some Mitsubishi products are supported (especially the 
one I have access to), but the application can easily be extended.

License
-------

Copyright 2015 - 2018 Manfred Hantschel

Climate-Tray is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or any
later version.

Climate-Tray is distributed in the hope that it will be useful,	but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.
